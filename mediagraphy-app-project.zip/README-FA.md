# ساخت APK اپ Mediagraphy World

من (Claude) داخل محیط خودم Android SDK و اینترنت ندارم، پس خود فایل APK را نمی‌توانم بسازم.
این پروژه همه‌چیز را آماده دارد و **GitHub Actions** (رایگان) APK را برایت می‌سازد.

## مرحله‌ی ۱ — ساخت APK قابل نصب (حدود ۱۰ دقیقه)
1. در github.com یک Repository جدید بساز (Private هم مشکلی ندارد).
2. **همه‌ی محتویات همین پوشه** (نه خود زیپ) را آپلود کن: `Add file → Upload files`.
   پوشه‌ی `.github` مخفی است؛ اگر آپلود نشد، از GitHub Desktop یا `git push` استفاده کن.
3. تب **Actions → Build Android APK → Run workflow**.
4. بعد از تمام شدن، پایین صفحه‌ی اجرا، بخش **Artifacts → android-apk** را دانلود کن.
   داخلش `mediagraphy-debug.apk` است: روی گوشی اندروید نصبش کن (اجازه‌ی «نصب از منبع ناشناس»).

## مرحله‌ی ۲ — APK امضاشده برای بازار / مایکت
نسخه‌ی debug برای فروشگاه‌ها قبول نمی‌شود. یک بار کلید بساز (روی کامپیوتر با JDK):

    keytool -genkeypair -v -keystore release.keystore -alias mw -keyalg RSA -keysize 2048 -validity 10000

**فایل release.keystore و رمزها را جایی امن نگه دار؛ اگر گم شود نمی‌توانی آپدیت بدهی.**
بعد در GitHub: `Settings → Secrets and variables → Actions` این ۴ مقدار را اضافه کن:
- `KEYSTORE_BASE64` ← خروجی `base64 -w0 release.keystore`
- `KEYSTORE_PASSWORD`، `KEY_ALIAS` (مثلاً mw)، `KEY_PASSWORD`

دوباره Run workflow بزن؛ این بار `mediagraphy-release.apk` هم تولید می‌شود.

## آپدیت اجباری
1. نسخه را در `package.json` بالا ببر (مثلاً 1.1.0) و دوباره APK بساز.
2. روی هاست (کنار سایت) فایل `version.json` را ویرایش کن:

       { "latest": "1.1.0", "min": "1.1.0", "message": "...", "links": { "bazaar": "...", "myket": "...", "direct": "..." } }

   - اپ‌هایی که نسخه‌شان **کمتر از min** باشد قفل می‌شوند و فقط دکمه‌های دانلود را می‌بینند.
   - نسخه‌ی کمتر از **latest** فقط یک نوار پیشنهاد آپدیت می‌بیند.
3. محدودیت: آپدیت اجباری فقط وقتی کار می‌کند که کاربر آنلاین باشد.

## نکته‌ها
- پوشه‌ی `site/` همان سایت است. برای محتوای جدید، فایل‌های سایت را جایگزین کن و دوباره Run workflow بزن؛ یا بدون ساخت APK جدید از «پک سوال» (تنظیمات) استفاده کن.
- آدرس هاست در `site/assets/mw-config.js` (فیلد HOST) است.
- یادآور روزانه فقط داخل اپ نصب‌شده کار می‌کند و اولین بار اجازه‌ی اعلان می‌خواهد.
- iOS: نیاز به Mac و Apple Developer دارد؛ برای آیفون فعلاً از «افزودن به صفحه‌ی اصلی» در Safari استفاده کنید.
- این پایپ‌لاین روی گوشی/GitHub واقعی تست نشده؛ اگر مرحله‌ای خطا داد، متن خطا را برایم بفرست.
