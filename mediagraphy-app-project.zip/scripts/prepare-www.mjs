// کپی سایت (پوشه‌ی site) به www و نوشتن شماره‌ی نسخه‌ی اپ داخل تنظیمات
import fs from "node:fs";
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
fs.rmSync("www", { recursive: true, force: true });
fs.cpSync("site", "www", { recursive: true });
const cfgPath = "www/assets/mw-config.js";
let cfg = fs.readFileSync(cfgPath, "utf8");
if (/APP_VERSION:\s*"[^"]*"/.test(cfg)) cfg = cfg.replace(/APP_VERSION:\s*"[^"]*"/, `APP_VERSION: "${pkg.version}"`);
else cfg = cfg.replace("window.MW_CONFIG = {", `window.MW_CONFIG = {\n  APP_VERSION: "${pkg.version}",`);
fs.writeFileSync(cfgPath, cfg);
console.log("www آماده شد — نسخه‌ی اپ:", pkg.version);
