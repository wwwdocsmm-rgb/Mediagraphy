// مجوزهای اعلان و شماره‌ی نسخه را بعد از «cap add android» اعمال می‌کند
import fs from "node:fs";
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const mp = "android/app/src/main/AndroidManifest.xml";
let m = fs.readFileSync(mp, "utf8");
const perms = ["android.permission.POST_NOTIFICATIONS", "android.permission.SCHEDULE_EXACT_ALARM", "android.permission.RECEIVE_BOOT_COMPLETED"];
for (const p of perms) if (!m.includes(p)) m = m.replace("<application", `<uses-permission android:name="${p}" />\n    <application`);
fs.writeFileSync(mp, m);
const gp = "android/app/build.gradle";
let g = fs.readFileSync(gp, "utf8");
const code = parseInt(process.env.GITHUB_RUN_NUMBER || "1", 10);
g = g.replace(/versionCode\s+\d+/, `versionCode ${code}`).replace(/versionName\s+"[^"]*"/, `versionName "${pkg.version}"`);
fs.writeFileSync(gp, g);
console.log("manifest و build.gradle اصلاح شد (نسخه", pkg.version, "کد", code + ")");
