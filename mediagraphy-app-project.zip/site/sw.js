/* Mediagraphy World — Service Worker: صفحه‌های دیده‌شده بعد از اولین بار آفلاین باز می‌شوند. نسخه را با هر انتشار عوض کن. */
const V = "mw-v1";
self.addEventListener("install", (e) => { self.skipWaiting(); e.waitUntil(caches.open(V).then((c) => Promise.allSettled(["./", "index.html", "settings.html", "league.html", "manifest.webmanifest", "assets/mw-config.js", "assets/mw-stats.js", "assets/mw-ui.js"].map((u) => c.add(u))))); });
self.addEventListener("activate", (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== V).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== location.origin) return;
  if (/\/(version\.json|packs\/manifest\.json)$/.test(u.pathname) || u.pathname.startsWith("/api/")) return;   // همیشه تازه
  const nav = r.mode === "navigate" || /\.html?$/.test(u.pathname);
  if (nav) {   // صفحه‌ها: اول شبکه، بعد کش
    e.respondWith(fetch(r).then((res) => { const cp = res.clone(); caches.open(V).then((c) => c.put(r, cp)); return res; }).catch(() => caches.match(r).then((m) => m || caches.match("index.html"))));
  } else {     // فایل‌های ثابت: کش و بعد به‌روزرسانی در پس‌زمینه
    e.respondWith(caches.match(r).then((m) => { const f = fetch(r).then((res) => { if (res.ok) { const cp = res.clone(); caches.open(V).then((c) => c.put(r, cp)); } return res; }).catch(() => m); return m || f; }));
  }
});
