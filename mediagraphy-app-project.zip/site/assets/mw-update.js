/* آپدیت اجباری: در اپ نصب‌شده، version.json هاست خوانده می‌شود. اگر نسخه‌ی اپ از «min» کمتر بود، صفحه قفل می‌شود. */
(function () {
  var CFG = window.MW_CONFIG || {}, C = window.Capacitor;
  var native = !!(C && C.isNativePlatform && C.isNativePlatform());
  if (!native || !CFG.HOST) return;
  var CUR = CFG.APP_VERSION || "0.0.0";
  function cmp(a, b) { a = String(a).split(".").map(Number); b = String(b).split(".").map(Number); for (var i = 0; i < 3; i++) { var d = (a[i] || 0) - (b[i] || 0); if (d) return d < 0 ? -1 : 1; } return 0; }
  function css() {
    var s = document.createElement("style");
    s.textContent = ".mw-upd{position:fixed;inset:0;z-index:2147483600;background:#0d1117;color:#e6edf3;display:flex;align-items:center;justify-content:center;padding:24px;direction:rtl;font-family:Vazirmatn,Tahoma,sans-serif;text-align:center}" +
      ".mw-upd>div{max-width:340px}.mw-upd img{width:130px;height:130px;object-fit:contain}.mw-upd h2{font-size:21px;margin:8px 0}.mw-upd p{font-size:14px;color:#9aa7b5;line-height:2;margin-bottom:16px}" +
      ".mw-upd a{display:block;padding:13px;border-radius:13px;background:#1c8bf0;color:#fff;text-decoration:none;font-weight:700;margin-top:9px}.mw-upd a.alt{background:#21262d;border:1px solid #30363d}" +
      ".mw-updbar{position:fixed;bottom:12px;left:12px;right:12px;z-index:2147483500;background:#161b22;border:1px solid #30363d;color:#e6edf3;border-radius:14px;padding:10px 14px;display:flex;gap:10px;align-items:center;direction:rtl;font:600 13px Vazirmatn,Tahoma,sans-serif}" +
      ".mw-updbar a{margin-right:auto;color:#8b9dff;text-decoration:none}.mw-updbar button{background:none;border:0;color:#8b949e;font-size:18px}";
    document.head.appendChild(s);
  }
  function links(v) {
    var L = v.links || {}, out = "";
    [["bazaar", "دانلود از بازار"], ["myket", "دانلود از مایکت"], ["direct", "دانلود مستقیم APK"]].forEach(function (x) { if (L[x[0]]) out += '<a ' + (x[0] === "direct" ? 'class="alt" ' : "") + 'href="' + L[x[0]] + '" target="_blank" rel="noopener">' + x[1] + "</a>"; });
    return out;
  }
  function force(v) {
    css(); var el = document.createElement("div"); el.className = "mw-upd"; el.setAttribute("data-mw", "1");
    el.innerHTML = '<div><img src="assets/mw-skull-sad.webp" alt=""><h2>نسخه‌ی جدید آمده 🚀</h2><p>' + (v.message || "برای ادامه، باید اپ را به‌روزرسانی کنی.") + "<br>نسخه‌ی تو: " + CUR + " · نسخه‌ی لازم: " + v.min + "</p>" + links(v) + "</div>";
    document.body.appendChild(el);
  }
  function soft(v) {
    var k = "mw:updskip:" + v.latest; if (localStorage.getItem(k) === new Date().toDateString()) return;
    css(); var b = document.createElement("div"); b.className = "mw-updbar"; b.setAttribute("data-mw", "1");
    var first = (v.links && (v.links.bazaar || v.links.myket || v.links.direct)) || "#";
    b.innerHTML = "<span>نسخه‌ی " + v.latest + " آماده است</span><a href=\"" + first + "\" target=\"_blank\" rel=\"noopener\">به‌روزرسانی</a><button aria-label=\"بستن\">×</button>";
    b.querySelector("button").onclick = function () { localStorage.setItem(k, new Date().toDateString()); b.remove(); };
    document.body.appendChild(b);
  }
  function check() {
    var ctl = new AbortController(), t = setTimeout(function () { ctl.abort(); }, 6000);
    fetch(CFG.HOST.replace(/\/$/, "") + "/version.json?t=" + Date.now(), { cache: "no-store", signal: ctl.signal })
      .then(function (r) { return r.ok ? r.json() : null; }).then(function (v) {
        clearTimeout(t); if (!v) return;
        if (v.min && cmp(CUR, v.min) < 0) force(v); else if (v.latest && cmp(CUR, v.latest) < 0) soft(v);
      }).catch(function () {});
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", check); else check();
  document.addEventListener("visibilitychange", function () { if (!document.hidden && !document.querySelector(".mw-upd")) check(); });
})();
