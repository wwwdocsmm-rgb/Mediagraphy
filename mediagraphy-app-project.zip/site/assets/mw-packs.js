/* پک‌های سؤال: ذخیره‌ی آفلاین در IndexedDB + هم‌گام‌سازی خودکار با هاست + افزودن دستی */
(function () {
  var CFG = window.MW_CONFIG || {}, DBN = "mw-packs", db = null;
  function open() {
    if (db) return Promise.resolve(db);
    return new Promise(function (res, rej) {
      var r = indexedDB.open(DBN, 1);
      r.onupgradeneeded = function () {
        var d = r.result;
        d.createObjectStore("packs", { keyPath: "id" });
        var s = d.createObjectStore("sessions", { keyPath: "key" }); s.createIndex("packId", "packId");
      };
      r.onsuccess = function () { db = r.result; res(db); }; r.onerror = function () { rej(r.error); };
    });
  }
  function run(store, mode, fn) {
    return open().then(function (d) {
      return new Promise(function (res, rej) {
        var t = d.transaction(store, mode), s = t.objectStore(store), out = fn(s);
        t.oncomplete = function () { res(typeof IDBRequest !== "undefined" && out instanceof IDBRequest ? out.result : out); }; t.onerror = function () { rej(t.error); };
      });
    });
  }
  function reqAll(s, q) { return q ? s.index("packId").getAll(q) : s.getAll(); }
  var P = {};
  P.list = function () { return run("packs", "readonly", function (s) { return s.getAll(); }).then(function (a) { return (a || []).sort(function (x, y) { return (x.order || 0) - (y.order || 0) || String(x.title).localeCompare(y.title); }); }); };
  P.get = function (id) { return run("packs", "readonly", function (s) { return s.get(id); }); };
  P.sessions = function (packId) {
    return run("sessions", "readonly", function (s) { return s.index("packId").getAll(packId); }).then(function (a) {
      return (a || []).sort(function (x, y) { return (x.order || 0) - (y.order || 0); });
    });
  };
  P.getSession = function (packId, id) { return run("sessions", "readonly", function (s) { return s.get(packId + "/" + id); }); };
  P.savePack = function (rec) { return run("packs", "readwrite", function (s) { return s.put(rec); }); };
  P.saveSession = function (rec) { rec.key = rec.packId + "/" + rec.id; return run("sessions", "readwrite", function (s) { return s.put(rec); }); };
  P.removeSession = function (packId, id) { return run("sessions", "readwrite", function (s) { return s.delete(packId + "/" + id); }); };
  P.removePack = function (id) {
    return P.sessions(id).then(function (list) {
      return Promise.all(list.map(function (x) { return P.removeSession(id, x.id); }));
    }).then(function () { return run("packs", "readwrite", function (s) { return s.delete(id); }); });
  };
  P.sizeOf = function (packId) { return P.sessions(packId).then(function (l) { return l.reduce(function (a, x) { return a + (x.html ? x.html.length : 0); }, 0); }); };

  /* ---------- افزودن دستی ---------- */
  function slug(t) { return String(t).trim().toLowerCase().replace(/[^\w\u0600-\u06FF]+/g, "-").replace(/^-+|-+$/g, "") || "pack"; }
  // items: [{name, lecturer, html}]
  P.importLocal = function (opt, items) {
    var id = opt.packId || ("local-" + slug(opt.title));
    return P.get(id).then(function (ex) {
      var rec = ex || { id: id, title: opt.title, icon: opt.icon || "📦", slot: opt.slot || "", version: 0, source: "local", order: 50, added: Date.now() };
      return P.sessions(id).then(function (cur) {
        var next = cur.reduce(function (m, x) { return Math.max(m, x.order || 0); }, 0);
        var jobs = items.map(function (it, i) {
          return P.saveSession({ packId: id, id: "u" + Date.now().toString(36) + i, title: it.name, lecturer: it.lecturer || "", html: it.html, order: next + i + 1, source: "local" });
        });
        return Promise.all(jobs).then(function () { rec.count = cur.length + items.length; return P.savePack(rec); }).then(function () { return id; });
      });
    });
  };

  /* ---------- هم‌گام‌سازی با هاست ---------- */
  function base() { return (CFG.HOST ? CFG.HOST.replace(/\/$/, "") + "/" : new URL("./", location.href).href); }
  P.manifestURL = function () { return base() + "packs/manifest.json"; };
  function fetchJSON(u) { return fetch(u + (u.indexOf("?") < 0 ? "?t=" + Date.now() : ""), { cache: "no-store" }).then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); }); }
  function fetchText(u) { return fetch(u, { cache: "no-store" }).then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.text(); }); }
  P.remote = function () { return fetchJSON(P.manifestURL()).then(function (m) { return (m && m.packs) || []; }); };
  // opts: {force:bool, ids:[...], onProgress(fn)}
  P.sync = function (opts) {
    opts = opts || {};
    if (!navigator.onLine) return Promise.resolve({ offline: true, updated: [], failed: [] });
    return Promise.all([P.remote(), P.list()]).then(function (r) {
      var remote = r[0], local = {}; r[1].forEach(function (p) { local[p.id] = p; });
      var rep = { updated: [], failed: [], available: [] };
      var chain = Promise.resolve();
      remote.forEach(function (rp, idx) {
        var cur = local[rp.id], wanted = rp.auto !== false || opts.force || (opts.ids && opts.ids.indexOf(rp.id) >= 0);
        var outdated = !cur || (cur.source === "remote" && (cur.version || 0) < (rp.version || 1));
        if (cur && cur.source === "local") outdated = false;
        if (!outdated) return;
        if (!wanted) { rep.available.push(rp); return; }
        chain = chain.then(function () {
          var done = 0, total = rp.sessions.length;
          return Promise.all(rp.sessions.map(function (s, i) {
            var u = base() + "packs/" + encodeURIComponent(rp.id) + "/" + encodeURIComponent(s.file);
            return fetchText(u).then(function (html) {
              done++; if (opts.onProgress) opts.onProgress(rp, done, total);
              return { packId: rp.id, id: String(s.id), title: s.title, lecturer: s.lecturer || "", html: html, order: s.order || i + 1, source: "remote" };
            });
          })).then(function (recs) {
            return Promise.all(recs.map(P.saveSession)).then(function () {
              var ids = recs.map(function (x) { return x.id; });
              return P.sessions(rp.id).then(function (all) {   // جلسه‌هایی که از پک حذف شده‌اند
                return Promise.all(all.filter(function (x) { return x.source === "remote" && ids.indexOf(x.id) < 0; }).map(function (x) { return P.removeSession(rp.id, x.id); }));
              });
            }).then(function () {
              return P.savePack({ id: rp.id, title: rp.title, icon: rp.icon || "📦", slot: rp.slot || "", version: rp.version || 1, source: "remote", order: rp.order || idx + 1, count: rp.sessions.length, synced: Date.now() });
            });
          }).then(function () { rep.updated.push(rp.id); });
        }).catch(function (e) { rep.failed.push({ id: rp.id, error: String(e && e.message || e) }); });
      });
      return chain.then(function () { try { localStorage.setItem("mw:packs:last", String(Date.now())); } catch (e) {} return rep; });
    });
  };
  // اجرای خودکار: وقتی آنلاین است و وقتی دوباره آنلاین می‌شود
  P.auto = function (cb) {
    function go() { P.sync().then(function (r) { if (cb && (r.updated.length || r.failed.length)) cb(r); }).catch(function () {}); }
    if (navigator.onLine) go(); window.addEventListener("online", go);
  };
  /* آماده‌ی اجرا برای viewer: متن HTML جلسه + اسکریپت‌های MW */
  P.prepare = function (html, key, back) {
    var HEAD = '<script>window.MW_KEY=' + JSON.stringify(key) + ';<\/script><script src="assets/mw-config.js"><\/script><script src="assets/mw-boot.js"><\/script>';
    var TAIL = (back ? '<a data-mw href="' + back + '" style="position:fixed;top:8px;right:8px;z-index:2147482000;background:rgba(13,17,23,.88);color:#e6edf3;border:1px solid #30363d;border-radius:999px;padding:4px 12px;font:700 12px Vazirmatn,Tahoma,sans-serif;text-decoration:none">\u21A9 \u0644\u06CC\u0633\u062A</a>' : '') + '<script src="assets/mw-stats.js"><\/script><script src="assets/mw-ui.js"><\/script><script src="assets/mw-league.js"><\/script><script src="assets/mw-core.js"><\/script>';
    html = html.replace(/<script src="\.\.\/assets\/mw-[^"]*"><\/script>/g, "");
    var m = /<head[^>]*>/i.exec(html);
    html = m ? html.slice(0, m.index + m[0].length) + HEAD + html.slice(m.index + m[0].length) : HEAD + html;
    var k = html.toLowerCase().lastIndexOf("</body>");
    return k >= 0 ? html.slice(0, k) + TAIL + html.slice(k) : html + TAIL;
  };
  P.slug = slug;
  window.MWPacks = P;
})();
