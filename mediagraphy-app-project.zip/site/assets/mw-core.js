/* هسته‌ی مشترک صفحه‌های کوییز: تایمر ۲۲ دقیقه‌ای، ادامه از آخرین سؤال، استریک و جشن روزانه */
(function () {
  if (window.__mwCore) return; window.__mwCore = true;
  var CFG = window.MW_CONFIG || {}, S = window.MWStats, UI = window.MWUI;
  var PATH = window.MW_KEY || location.pathname.split("/").slice(-2).join("/");
  var LOGK = "mw:log:" + PATH, TK = "mw:t:" + PATH, GUARD = "mw:reloaded:" + PATH;
  var TIMER = CFG.TIMER_SECONDS || 1320, EXT = CFG.EXTEND_SECONDS || 1200;
  var rnd = window.__mwRandom || Math.random;
  var origST = window.setTimeout.bind(window), origSI = window.setInterval.bind(window);
  var replaying = false, finished = false, OWN = false;   // OWN: صفحه خودش «ادامه از آخرین سؤال» دارد
  function fa(n) { return S.fa(n); }
  function isEn() { return (document.documentElement.lang || "fa").slice(0, 2) === "en"; }
  function T(f, e) { return isEn() ? e : f; }
  function jget(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }
  function jset(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function del(k) { try { localStorage.removeItem(k); } catch (e) {} }

  /* ---------- استایل ---------- */
  var st = document.createElement("style");
  st.textContent =
    "#mw-timer{position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:2147482000;pointer-events:none;font:700 13px Vazirmatn,Tahoma,sans-serif;" +
    "background:rgba(13,17,23,.88);color:#e6edf3;border:1px solid #30363d;border-radius:999px;padding:4px 12px;direction:ltr;box-shadow:0 2px 8px rgba(0,0,0,.35)}" +
    "#mw-timer.warn{color:#ffd166;border-color:#a8791f}#mw-timer.crit{color:#ff7b72;border-color:#a8302c}" +
    ".mw-modal{position:fixed;inset:0;z-index:2147483100;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;padding:18px;direction:rtl;font-family:Vazirmatn,Tahoma,sans-serif}" +
    ".mw-modal>div{background:#161b22;color:#e6edf3;border:1px solid #30363d;border-radius:16px;padding:22px 18px;width:min(92vw,360px);text-align:center}" +
    ".mw-modal h3{font-size:19px;margin-bottom:8px}.mw-modal p{font-size:14px;color:#9aa7b5;margin-bottom:16px;line-height:1.9}" +
    ".mw-modal button{display:block;width:100%;margin-top:8px;padding:12px;border-radius:12px;border:0;font:700 15px Vazirmatn,Tahoma,sans-serif;cursor:pointer;background:#238636;color:#fff}" +
    ".mw-modal button.n{background:#21262d;color:#e6edf3;border:1px solid #30363d}" +
    "#mw-toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:2147482500;background:#161b22;color:#e6edf3;border:1px solid #30363d;border-radius:12px;padding:9px 16px;font:600 13px Vazirmatn,Tahoma,sans-serif;direction:rtl;pointer-events:none}";
  document.head.appendChild(st);
  function toast(t) { var d = document.createElement("div"); d.id = "mw-toast"; d.setAttribute("data-mw", "1"); d.textContent = t; document.body.appendChild(d); origST(function () { d.remove(); }, 2600); }

  /* ---------- تشخیص عناصر ---------- */
  var CL = "button,[onclick],a[href],label,select,summary,[role='button'],input";
  function vis(e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  var _clickables = function () { return []; };
  var ON_RE = /select(Answer|Option)|choose|pick|answer\(/i, CLS_RE = /(^|[\s_-])(opt|option|choice|answer)([\s_-]|$)/i, NOT_RE = /draft|edit|review|result|explain/i;
  function cls(e) { return typeof e.className === "string" ? e.className : ""; }
  function isOpt(e) { var oc = e.getAttribute && e.getAttribute("onclick") || ""; var c = cls(e); return ON_RE.test(oc) || (CLS_RE.test(c) && !NOT_RE.test(c)); }
  function optsList() {
    var all = Array.prototype.filter.call(document.querySelectorAll("body *"), function (e) { return !e.closest("[data-mw]") && isOpt(e) && vis(e); });
    return all.filter(function (e) { return !all.some(function (o) { return o !== e && o.contains(e); }); });
  }
  function clickables() {
    var set = [], seen = new Set();
    Array.prototype.forEach.call(document.querySelectorAll(CL), function (e) { if (!e.closest("[data-mw]") && vis(e)) { seen.add(e); set.push(e); } });
    optsList().forEach(function (e) { if (!seen.has(e)) { seen.add(e); set.push(e); } });
    set.sort(function (a, b) { return a === b ? 0 : (a.compareDocumentPosition(b) & 4) ? -1 : 1; });
    return set;
  }
  function closestClickable(t, list) { var set = new Set(list); for (var n = t, d = 0; n && n !== document.documentElement && d < 12; n = n.parentElement, d++) if (set.has(n)) return n; return null; }
  var OK_RE = /(^|[\s_-])(correct|ok|right|success)([\s_-]|$)/i, BAD_RE = /(^|[\s_-])(wrong|bad|incorrect|error|fail)([\s_-]|$)/i, MARK_RE = /(^|[\s_-])(correct|ok|right|wrong|bad|incorrect|chosen|selected|picked|answered|locked)([\s_-]|$)/i;
  function marked(e) { return MARK_RE.test(cls(e)); }
  function anyMarked(list) { return list.some(marked); }

  /* ---------- لاگ کلیک‌ها برای بازسازی ---------- */
  var log = [];
  function sig() { var a = document.getElementById("app") || document.body; return (a.textContent || "").length; }
  var SIG0;
  function saveLog() { jset(LOGK, { sig: SIG0, log: log, ts: Date.now() }); }
  function resetAttempt() {
    log = []; del(LOGK); del(TK); finished = false;
    if (window.__mwReseed) window.__mwReseed();
    timer.reset();
  }
  function replay(done, fail) {
    var i = 0; replaying = true;
    window.setTimeout = function (fn, ms) { var a = [].slice.call(arguments, 2); return origST.apply(window, [fn, 0].concat(a)); };
    function end(ok) { origST(function () { window.setTimeout = origST; replaying = false; (ok ? done : fail)(); }, 150); }
    (function step() {
      if (i >= log.length) return end(true);
      var el = clickables()[log[i]];
      if (!el) return end(false);
      try { el.click(); } catch (e) { return end(false); }
      i++; origST(step, 25);
    })();
  }

  /* ---------- تایمر ---------- */
  var timer = (function () {
    var rem = TIMER, off = false, pill = null, modal = false, iv = null;
    var saved = jget(TK); if (saved && typeof saved.rem === "number") { rem = saved.rem; off = !!saved.off; }
    function fmt(s) { s = Math.max(0, s); var m = Math.floor(s / 60), x = s % 60; return (m < 10 ? "0" : "") + m + ":" + (x < 10 ? "0" : "") + x; }
    function persist() { jset(TK, { rem: rem, off: off }); }
    function paint() {
      if (off || finished) { if (pill) pill.style.display = "none"; return; }
      if (!pill) { pill = document.createElement("div"); pill.id = "mw-timer"; pill.setAttribute("data-mw", "1"); document.body.appendChild(pill); }
      pill.style.display = ""; pill.textContent = "⏱ " + fmt(rem); pill.className = rem <= 60 ? "crit" : rem <= 180 ? "warn" : "";
    }
    function ask() {
      modal = true; var m = document.createElement("div"); m.className = "mw-modal"; m.setAttribute("data-mw", "1");
      m.innerHTML = "<div><h3>" + T("⏰ زمانت تموم شد", "⏰ Time is up") + "</h3><p>" + T("می‌خوای " + fa(EXT / 60) + " دقیقه دیگر زمان داشته باشی؟", "Do you want " + EXT / 60 + " more minutes?") + "</p>" +
        '<button data-a="y">' + T("آره، ادامه می‌دم", "Yes, continue") + '</button><button class="n" data-a="n">' + T("نه، بدون تایمر ادامه می‌دم", "No, continue without timer") + "</button></div>";
      m.addEventListener("click", function (e) {
        var a = e.target.getAttribute("data-a"); if (!a) return;
        if (a === "y") rem = EXT; else off = true;
        persist(); modal = false; m.remove(); paint();
      });
      document.body.appendChild(m);
    }
    function tick() {
      if (off || finished || modal || document.hidden || replaying) return;
      rem--; persist(); paint(); if (rem <= 0) ask();
    }
    return {
      start: function () {
        var own = document.querySelector("#examTimer,.exam-timer,[id*='timer' i],[class*='timer' i]") || /⏱\s*\d{1,2}:\d{2}/.test(document.body.innerText || "");
        if (own) { off = true; return; }                 // صفحه تایمر خودش را دارد؛ تایمر دوم نمی‌گذاریم
        paint(); if (rem <= 0 && !off) ask(); iv = origSI(tick, 1000);
      },
      stopFinished: function () { finished = true; del(TK); paint(); },
      reset: function () { rem = TIMER; off = false; modal = false; document.querySelectorAll(".mw-modal").forEach(function (x) { x.remove(); }); paint(); }
    };
  })();

  /* ---------- شمارش پاسخ / بازدهی / جشن ---------- */
  var pending = null;
  function onAnswerClick(optEl) {
    var list = optsList(), idx = -1; list.forEach(function (e, i) { if (idx < 0 && (e === optEl || e.contains(optEl))) idx = i; }); if (idx < 0) return; optEl = list[idx];
    var already = anyMarked(list);
    pending = { already: already, idx: idx, el: optEl };
    var p = pending;
    origST(function () { judge(p, 0); }, 70);
  }
  function judge(p, tries) {
    var list = optsList(), el = (list.length && list[p.idx]) || p.el;
    var now = anyMarked(list) || marked(p.el);
    if (p.already) return;                          // سؤالِ قبلاً پاسخ‌داده‌شده
    if (!now) { if (tries < 4) origST(function () { judge(p, tries + 1); }, 120); return; }  // پاسخ ثبت نشد
    var c = null, node = marked(p.el) ? p.el : el;
    if (OK_RE.test(cls(node))) c = true; else if (BAD_RE.test(cls(node))) c = false;
    var r = S.record(c);
    if (r.justDone) {
      var wb = S.weekBest(r.stats), pct = S.acc(r.day);
      origST(function () {
        UI.celebrate({ streak: r.streak, pct: pct, weekBest: !!(wb && wb.key === S.dkey()), newRecord: r.newRecord, prevBest: r.prevBest, cup: r.cup, answered: r.day.a });
        if (window.MWLeague && window.MWLeague.sync) window.MWLeague.sync();
        if (window.MWNative && window.MWNative.refresh) window.MWNative.refresh();
      }, 600);
    }
  }

  document.addEventListener("click", function (e) {
    if (replaying || !e.isTrusted) return;
    var t = e.target; if (!t || !t.closest || t.closest("[data-mw]")) return;
    var cl = clickables(), el = closestClickable(t, cl);
    if (el && !OWN && !finished) { var i = cl.indexOf(el); if (i >= 0) { log.push(i); saveLog(); } }
    var n = t, o = null; for (var d = 0; n && n !== document.body && d < 7; d++, n = n.parentElement) { if (isOpt(n)) { o = n; break; } }
    if (o) onAnswerClick(o);
    if (el && /restart/i.test((el.getAttribute("onclick") || "") + " " + (el.id || ""))) { /* با wrapper هم پوشش داده می‌شود */ }
  }, true);

  /* ---------- پایان آزمون ---------- */
  var RES_SEL = "#result-screen,#result,#results,.result-screen,#summary,#summary-screen,#final-screen,#res,.results,.card.rv";
  function resultVisible() {
    var n = document.querySelectorAll(RES_SEL);
    for (var i = 0; i < n.length; i++) { var r = n[i].getBoundingClientRect(); if (r.height > 80 && r.width > 80 && getComputedStyle(n[i]).visibility !== "hidden") return true; }
    return false;
  }
  function onFinish() { if (finished) return; finished = true; timer.stopFinished(); log = []; del(LOGK); if (window.__mwReseed) window.__mwReseed(); }

  /* ---------- شروع ---------- */
  function wrapRestart() {
    ["restart", "restartQuiz", "retryQuiz", "newSession"].forEach(function (nm) {
      var f = window[nm]; if (typeof f !== "function" || f.__mw) return;
      var w = function () { resetAttempt(); return f.apply(this, arguments); }; w.__mw = 1; window[nm] = w;
    });
  }
  function boot() {
    wrapRestart(); SIG0 = sig();
    OWN = /resumeYes|resumeNo|resume-overlay|resume-modal|resume-banner|resumeContinueBtn|quizState_/.test(document.documentElement.innerHTML);
    var saved = jget(LOGK), go = function () { timer.start(); origSI(function () { if (!finished && !replaying && resultVisible()) onFinish(); }, 800); };
    if (OWN) { del(LOGK); go(); return; }
    if (saved && saved.log && saved.log.length && saved.sig === SIG0) {
      log = saved.log.slice();
      replay(function () { toast(T("✅ از همان‌جایی که بودی ادامه می‌دهیم", "✅ Resumed where you left off")); go(); },
        function () {
          log = []; del(LOGK); del("mw:seed:" + PATH);
          if (!sessionStorage.getItem(GUARD)) { sessionStorage.setItem(GUARD, "1"); location.reload(); } else go();
        });
    } else { if (saved) del(LOGK); sessionStorage.removeItem(GUARD); go(); }
  }
  if (document.readyState === "complete") origST(boot, 30); else window.addEventListener("load", function () { origST(boot, 30); });
  window.MWCore = { resetAttempt: resetAttempt, _log: function () { return log; }, _opts: optsList, _click: clickables, _finished: function () { return finished; } };
})();
