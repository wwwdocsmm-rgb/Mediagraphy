/* کلاینت لیگ ستارگان: همگام‌سازی امتیاز هفتگی و گرفتن جدول رتبه */
(function () {
  var CFG = window.MW_CONFIG || {}, S = window.MWStats;
  function api(p) { return (CFG.API || "").replace(/\/+$/, "") + p; }
  function uid() {
    var k = "mw:uid", v = localStorage.getItem(k);
    if (!v) { v = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : (Date.now().toString(16) + Math.floor((window.__mwRandom || Math.random)() * 1e12).toString(16) + "0000000000000000"); try { localStorage.setItem(k, v); } catch (e) {} }
    return v;
  }
  function name() {
    var s = S.load(), n = (s.name || "").trim();
    if (!n) { try { n = (JSON.parse(localStorage.getItem("mw:settings")) || {}).leagueName || ""; } catch (e) {} }
    return (n || "").trim() || ("دانشجو " + uid().replace(/[^0-9a-f]/gi, "").slice(0, 4));
  }
  function week() { return S.weekDays()[0]; }
  function enabled() { return !!CFG.API; }
  function sync() {
    if (!enabled() || navigator.onLine === false) return Promise.resolve(null);
    var m = S.compact();
    return fetch(api("/league/sync"), { method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: uid(), name: name(), week: week(), answered: m.answered, correct: m.correct, days: m.days, streak: m.streak }) })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }).catch(function () { return null; });
  }
  function top() {
    if (!enabled()) return Promise.reject(new Error("disabled"));
    return fetch(api("/league/top?week=" + week() + "&id=" + encodeURIComponent(uid())), { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); });
  }
  window.MWLeague = { enabled: enabled, sync: sync, top: top, uid: uid, name: name, week: week };
})();
