/* تنظیمات مشترک Mediagraphy World — قبل از انتشار مقدار HOST و API را بگذار */
window.MW_CONFIG = {
  APP_VERSION: "1.0.0",   // نسخه‌ی اپ نصبی؛ موقع ساخت APK خودکار از package.json جایگزین می‌شود
  HOST: "https://deluxe-daffodil-ca8c5a.netlify.app",            // مثال: "https://mediagraphy.pages.dev"  (برای لینک اشتراک‌گذاری)
  API:  "",            // مثال: "https://mw-league.<account>.workers.dev"  (بک‌اند لیگ؛ خالی = لیگ آفلاین/محلی)
  TIMER_SECONDS: 22 * 60,   // تایمر هر جلسه
  EXTEND_SECONDS: 20 * 60,  // تمدید بعد از اتمام زمان
  DAILY_GOAL: 10,           // حداقل پاسخ برای حساب شدن «آزمون امروز»
  CUP_DAYS: 7               // کاپ مداومت
};
