/* انیمیشن جشن (کاغذرنگی پیوسته)، کارت اشتراک رکورد */
(function () {
  var S = window.MWStats, CFG = window.MW_CONFIG || {};
  var BASE = (function () { var s = document.currentScript; return s ? s.src.replace(/[^\/]*$/, "") : ""; })();
  var rnd = window.__mwRandom || Math.random;
  var FONT = "Vazirmatn, Tahoma, sans-serif";

  function css() {
    if (document.getElementById("mw-ui-css")) return;
    var st = document.createElement("style"); st.id = "mw-ui-css";
    st.textContent =
      ".mw-cele{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;overflow:hidden;" +
      "background:linear-gradient(165deg,#d6ebff 0%,#7db4f2 45%,#2f66d8 100%);font-family:" + FONT + ";direction:rtl;animation:mwFade .35s ease}" +
      ".mw-cele.mw-dark{background:linear-gradient(165deg,#0b1d44,#1b3a86 60%,#2f66d8)}" +
      ".mw-rays{position:absolute;inset:-50%;background:repeating-conic-gradient(from 0deg,rgba(255,255,255,.22) 0 8deg,rgba(255,255,255,0) 8deg 24deg);animation:mwSpin 28s linear infinite;pointer-events:none}" +
      ".mw-cele canvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}" +
      ".mw-card{position:relative;z-index:2;width:min(92vw,380px);text-align:center;color:#0c2a63;padding:8px 16px 18px}" +
      ".mw-skull{width:150px;height:150px;object-fit:contain;animation:mwBounce 1.6s ease-in-out infinite;filter:drop-shadow(0 8px 14px rgba(0,30,90,.35))}" +
      ".mw-title{font-size:30px;font-weight:800;margin:4px 0 2px;color:#fff;text-shadow:0 3px 10px rgba(0,40,120,.45)}" +
      ".mw-sub{font-size:14px;color:#eaf4ff;margin-bottom:14px}" +
      ".mw-chips{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:12px}" +
      ".mw-chip{background:rgba(255,255,255,.92);border-radius:14px;padding:8px 14px;font-size:13px;font-weight:700;color:#12418f;box-shadow:0 4px 12px rgba(0,40,120,.2)}" +
      ".mw-chip b{font-size:20px;display:block;color:#0b5fa8}" +
      ".mw-streak{background:rgba(255,255,255,.95);border-radius:18px;padding:12px 14px;margin-bottom:14px;box-shadow:0 6px 18px rgba(0,40,120,.25)}" +
      ".mw-streak .n{font-size:46px;font-weight:800;line-height:1.1;color:#f08a00}" +
      ".mw-streak .l{font-size:14px;font-weight:700;color:#d97800}" +
      ".mw-streak .m{font-size:13px;color:#33507f;margin-top:6px;line-height:1.8}" +
      ".mw-days{display:flex;gap:5px;justify-content:center;margin-top:8px}" +
      ".mw-days i{width:30px;height:30px;border-radius:50%;background:#dce8fa;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:13px;color:#7b93bf}" +
      ".mw-days i.on{background:#ffb02e;color:#fff;box-shadow:0 0 0 3px #ffe2a8}" +
      ".mw-btns{display:flex;flex-direction:column;gap:9px}" +
      ".mw-btn{border:0;border-bottom:4px solid #0a4a8c;background:#1c8bf0;color:#fff;font:700 16px " + FONT + ";padding:13px;border-radius:14px;cursor:pointer}" +
      ".mw-btn.alt{background:#fff;color:#1356b5;border-bottom-color:#b9cdee}" +
      ".mw-btn:active{transform:translateY(2px);border-bottom-width:2px}" +
      "@keyframes mwFade{from{opacity:0}to{opacity:1}}@keyframes mwSpin{to{transform:rotate(360deg)}}" +
      "@keyframes mwBounce{0%,100%{transform:translateY(0) rotate(-3deg)}50%{transform:translateY(-14px) rotate(3deg)}}";
    document.head.appendChild(st);
  }

  /* کاغذرنگی پیوسته: هر ذره بعد از خروج از صفحه دوباره از بالا می‌آید (هیچ‌وقت قطع نمی‌شود) */
  function confetti(canvas) {
    var ctx = canvas.getContext("2d"), W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 2), parts = [], run = true;
    var COLORS = ["#ff4d4d", "#ffb02e", "#ffe14d", "#3ddc84", "#34c3ff", "#ffffff", "#b073ff", "#ff7ac8"];
    function size() { W = canvas.clientWidth; H = canvas.clientHeight; canvas.width = W * dpr; canvas.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
    function mk(initial) {
      return { x: rnd() * W, y: initial ? rnd() * H : -20 - rnd() * 60, w: 6 + rnd() * 8, h: 10 + rnd() * 12, vy: 1.4 + rnd() * 2.4,
        vx: (rnd() - .5) * 1.2, r: rnd() * 6.28, vr: (rnd() - .5) * .22, sw: rnd() * 6.28, vs: .03 + rnd() * .05, c: COLORS[(rnd() * COLORS.length) | 0] };
    }
    size(); var N = Math.round(Math.min(150, Math.max(70, W / 3)));
    for (var i = 0; i < N; i++) parts.push(mk(true));
    function frame() {
      if (!run) return; ctx.clearRect(0, 0, W, H);
      parts.forEach(function (p, i) {
        p.y += p.vy; p.x += p.vx + Math.sin(p.sw) * .8; p.r += p.vr; p.sw += p.vs;
        if (p.y > H + 24) parts[i] = mk(false);
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.scale(1, Math.cos(p.sw)); ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); ctx.restore();
      });
      requestAnimationFrame(frame);
    }
    window.addEventListener("resize", size); frame();
    return function stop() { run = false; window.removeEventListener("resize", size); };
  }

  function roundRect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }

  /* کارت تصویری رکورد برای اشتراک */
  function shareCard(info) {
    return new Promise(function (resolve) {
      var c = document.createElement("canvas"); c.width = 1080; c.height = 1350; var g = c.getContext("2d");
      var bg = g.createLinearGradient(0, 0, 0, 1350); bg.addColorStop(0, "#d6ebff"); bg.addColorStop(.45, "#7db4f2"); bg.addColorStop(1, "#2f66d8");
      g.fillStyle = bg; g.fillRect(0, 0, 1080, 1350);
      g.save(); g.translate(540, 520); g.fillStyle = "rgba(255,255,255,.18)";
      for (var i = 0; i < 15; i++) { g.rotate(Math.PI * 2 / 15); g.beginPath(); g.moveTo(0, 0); g.lineTo(1200, -110); g.lineTo(1200, 110); g.fill(); }
      g.restore();
      var cols = ["#ff4d4d", "#ffb02e", "#ffe14d", "#3ddc84", "#34c3ff", "#ffffff", "#b073ff"], k = 1;
      for (var j = 0; j < 70; j++) { k = (k * 16807) % 2147483647; var x = k % 1080; k = (k * 16807) % 2147483647; var y = k % 1350;
        g.save(); g.translate(x, y); g.rotate(j); g.fillStyle = cols[j % cols.length]; g.fillRect(-7, -12, 14, 24); g.restore(); }
      g.textAlign = "center"; g.direction = "rtl";
      var img = new Image();
      function draw() {
        if (img.width) g.drawImage(img, 340, 120, 400, 400);
        g.fillStyle = "#fff"; g.font = "800 84px " + FONT; g.shadowColor = "rgba(0,40,120,.5)"; g.shadowBlur = 16; g.fillText(info.title || "ایول ترکوندی!", 540, 640); g.shadowBlur = 0;
        roundRect(g, 120, 690, 840, 330, 40); g.fillStyle = "rgba(255,255,255,.95)"; g.fill();
        g.fillStyle = "#f08a00"; g.font = "800 190px " + FONT; g.fillText(S.fa(info.streak), 540, 880);
        g.fillStyle = "#d97800"; g.font = "700 48px " + FONT; g.fillText("روز استقامت 🔥", 540, 950);
        g.fillStyle = "#12418f"; g.font = "700 44px " + FONT;
        var line = []; if (info.pct != null) line.push("بازدهی " + S.fa(info.pct) + "٪"); if (info.weekBest) line.push("🏅 بهترین عملکرد هفته");
        g.fillText(line.join("   ·   ") || "هر روز یک قدم", 540, 1000);
        g.fillStyle = "#fff"; g.font = "700 46px " + FONT; g.fillText("Mediagraphy World", 540, 1180);
        g.font = "400 34px " + FONT; g.fillStyle = "#e6f1ff"; g.fillText(CFG.HOST ? CFG.HOST.replace(/^https?:\/\//, "") : "mediagraphy_team", 540, 1240);
        c.toBlob(function (b) { resolve(b); }, "image/png");
      }
      img.onload = draw; img.onerror = draw; img.src = BASE + "mw-skull-fire.webp";
    });
  }

  function share(info) {
    var text = "🔥 " + S.fa(info.streak) + " روز استقامت در Mediagraphy World" + (info.pct != null ? " — بازدهی " + S.fa(info.pct) + "٪" : "") + (CFG.HOST ? "\n" + CFG.HOST : "");
    return shareCard(info).then(function (blob) {
      var file = blob && new File([blob], "mediagraphy-record.png", { type: "image/png" });
      if (navigator.canShare && file && navigator.canShare({ files: [file] })) return navigator.share({ files: [file], text: text }).catch(function () {});
      if (navigator.share) return navigator.share({ text: text }).catch(function () {});
      if (blob) { var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "mediagraphy-record.png"; document.body.appendChild(a); a.click(); a.remove(); }
    });
  }

  /* صفحه‌ی جشن. opts: {streak, pct, weekBest, newRecord, prevBest, cup, answered, title, sub, skull, onClose} */
  function celebrate(o) {
    css(); var cup = S.CUP, cur = o.streak, left = Math.max(0, cup - (cur % cup || cup));
    var el = document.createElement("div"); el.className = "mw-cele"; el.setAttribute("data-mw", "1");
    var days = ""; var wk = S.weekDays(), st = S.load();
    var names = ["ش", "ی", "د", "س", "چ", "پ", "ج"];
    wk.forEach(function (k, i) { var d = st.days[k]; days += '<i class="' + (d && d.done ? "on" : "") + '">' + names[i] + "</i>"; });
    var msg;
    if (o.cup) msg = "🏆 کاپ " + S.fa(cup) + " روز مداومت مال توئه!";
    else if (o.newRecord) msg = "داری رکورد می‌زنی! رکورد قبلی‌ات " + S.fa(o.prevBest) + " روز بود. تا کاپ " + S.fa(cup) + " روز مداومت " + S.fa(left) + " روز دیگه مونده.";
    else if (cur === 1) msg = "شروع خوبی بود! " + S.fa(cup) + " روز پشت‌سرهم بیا تا کاپ مداومت رو بگیری.";
    else msg = "روز " + S.fa(cur) + " استقامت! تا کاپ " + S.fa(cup) + " روز مداومت " + S.fa(left) + " روز دیگه مونده.";
    el.innerHTML = '<div class="mw-rays"></div><canvas></canvas><div class="mw-card">' +
      '<img class="mw-skull" alt="" src="' + BASE + (o.skull || "mw-skull-fire.webp") + '">' +
      '<div class="mw-title">' + (o.title || "ایول ترکوندی! 💥") + "</div>" +
      '<div class="mw-sub">' + (o.sub || "آزمون امروزت کامل شد") + "</div>" +
      '<div class="mw-chips">' + (o.pct != null ? '<div class="mw-chip">بازدهی امروز<b>' + S.fa(o.pct) + "٪</b></div>" : "") +
      '<div class="mw-chip">پاسخ امروز<b>' + S.fa(o.answered || S.GOAL) + "</b></div>" +
      (o.weekBest ? '<div class="mw-chip">🏅<b style="font-size:13px">بهترین عملکرد این هفته</b></div>' : "") + "</div>" +
      '<div class="mw-streak"><div class="n">' + S.fa(cur) + '</div><div class="l">روز استقامت 🔥</div><div class="m">' + msg + '</div><div class="mw-days">' + days + "</div></div>" +
      '<div class="mw-btns"><button class="mw-btn" data-a="share">اشتراک رکوردم 📤</button><button class="mw-btn alt" data-a="close">ادامه</button></div></div>';
    document.body.appendChild(el);
    var stop = confetti(el.querySelector("canvas"));
    el.addEventListener("click", function (e) {
      var a = e.target.getAttribute && e.target.getAttribute("data-a");
      if (a === "share") share({ streak: cur, pct: o.pct, weekBest: o.weekBest });
      if (a === "close") { stop(); el.remove(); o.onClose && o.onClose(); }
    });
    return el;
  }

  window.MWUI = { celebrate: celebrate, share: share, confetti: confetti, css: css, BASE: BASE };
})();
