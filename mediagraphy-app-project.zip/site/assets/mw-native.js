/* پل اپ (Capacitor): یادآور محلی «امروز آزمون ندادی». در مرورگر عادی کاری نمی‌کند. */
(function () {
  var C = window.Capacitor, S = window.MWStats;
  var isNative = !!(C && C.isNativePlatform && C.isNativePlatform());
  var LN = isNative && C.Plugins && C.Plugins.LocalNotifications;
  var BASE = 7100, DAYS = 14;
  function fa(n) { return S ? S.fa(n) : n; }
  function settings() { try { return JSON.parse(localStorage.getItem("mw:settings")) || {}; } catch (e) { return {}; } }
  async function cancelAll() {
    try {
      var p = await LN.getPending();
      var mine = ((p && p.notifications) || []).filter(function (n) { return n.id >= BASE && n.id < BASE + 100; }).map(function (n) { return { id: n.id }; });
      if (mine.length) await LN.cancel({ notifications: mine });
    } catch (e) {}
  }
  async function schedule(h, m) {
    if (!LN) return false;
    var perm = await LN.checkPermissions();
    if (perm.display !== "granted") { perm = await LN.requestPermissions(); if (perm.display !== "granted") return false; }
    await cancelAll();
    var st = S.load(), cur = S.streakNow(st), doneToday = st.streak.last === S.dkey(), now = new Date(), list = [];
    for (var i = 0; i < DAYS; i++) {
      var d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i, h, m, 0);
      if (d <= now) continue;
      if (i === 0 && doneToday) continue;                  // امروز آزمون داده؛ امروز یادآور نده
      list.push({ id: BASE + i, title: "امروز آزمون ندادی ها؟ 😅",
        body: cur > 0 ? "استریک " + fa(cur) + " روزه‌ات در خطره! فقط " + fa(S.GOAL) + " سؤال بزن." : "فقط " + fa(S.GOAL) + " سؤال تا شروع استریکت!",
        schedule: { at: d, allowWhileIdle: true } });
    }
    if (list.length) await LN.schedule({ notifications: list });
    return true;
  }
  window.MWNative = {
    isNative: isNative,
    setReminder: async function (on, h, m) { if (!isNative) return false; if (!on) { await cancelAll(); return true; } return schedule(h, m); },
    refresh: async function () { var s = settings(); if (!isNative || !s.remOn) return false; var t = (s.remTime || "20:00").split(":"); return schedule(+t[0], +t[1]); }
  };
  if (isNative) {
    setTimeout(function () { window.MWNative.refresh(); }, 1500);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) window.MWNative.refresh(); });
  }
})();
