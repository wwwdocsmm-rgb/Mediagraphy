/* آمار محلی: استریک، پاسخ‌های روزانه، بازدهی، بهترین عملکرد هفته */
(function () {
  var CFG = window.MW_CONFIG || {};
  var SK = "mw:stats";
  var GOAL = CFG.DAILY_GOAL || 10, CUP = CFG.CUP_DAYS || 7;
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function dkey(d) { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function parse(k) { var p = k.split("-"); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function addDays(k, n) { var d = parse(k); d.setDate(d.getDate() + n); return dkey(d); }
  function fresh() { return { days: {}, streak: { cur: 0, best: 0, last: "" }, cups: 0, name: "" }; }
  function load() {
    try { var s = JSON.parse(localStorage.getItem(SK)); if (s && s.days && s.streak) return s; } catch (e) {}
    return fresh();
  }
  function save(s) { try { localStorage.setItem(SK, JSON.stringify(s)); } catch (e) {} }
  function acc(d) { return d && d.k > 0 ? Math.round(100 * d.c / d.k) : null; }
  function weekStart(k) { var d = parse(k); d.setDate(d.getDate() - ((d.getDay() + 1) % 7)); return dkey(d); } // شنبه = شروع هفته
  function weekDays(k) { var ws = weekStart(k || dkey()), a = []; for (var i = 0; i < 7; i++) a.push(addDays(ws, i)); return a; }
  function weekBest(s) {
    s = s || load(); var best = null;
    weekDays().forEach(function (k) {
      var d = s.days[k]; if (!d || d.a < GOAL) return;
      var p = acc(d); if (p === null) return;
      if (!best || p > best.pct) best = { key: k, pct: p, a: d.a };
    });
    return best;
  }
  function streakNow(s) {
    s = s || load(); var k = dkey();
    return (s.streak.last === k || s.streak.last === addDays(k, -1)) ? s.streak.cur : 0;
  }
  // correct: true | false | null(نامشخص)
  function record(correct) {
    var s = load(), k = dkey(); var d = s.days[k] || (s.days[k] = { a: 0, c: 0, k: 0 });
    d.a++; if (correct === true) { d.c++; d.k++; } else if (correct === false) { d.k++; }
    var res = { justDone: false, newRecord: false, cup: false, prevBest: s.streak.best };
    if (d.a >= GOAL && !d.done) {
      d.done = true; res.justDone = true;
      var st = s.streak;
      if (st.last === addDays(k, -1)) st.cur++; else if (st.last !== k) st.cur = 1;
      st.last = k;
      res.newRecord = st.cur > st.best && st.best > 0;
      if (st.cur > st.best) st.best = st.cur;
      if (st.cur % CUP === 0) { s.cups = (s.cups || 0) + 1; res.cup = true; }
    }
    save(s); res.stats = s; res.day = d; res.streak = s.streak.cur;
    return res;
  }
  function compact(s) { // خلاصه‌ی ارسال به لیگ (بدون جزئیات خصوصی)
    s = s || load(); var wk = weekDays(), a = 0, c = 0, k = 0, days = 0;
    wk.forEach(function (x) { var d = s.days[x]; if (d) { a += d.a; c += d.c; k += d.k; if (d.a >= GOAL) days++; } });
    return { week: wk[0], answered: a, correct: c, known: k, days: days, streak: streakNow(s), best: s.streak.best, cups: s.cups || 0 };
  }
  function weekPoints(s) { var m = compact(s); return m.correct * 10 + (m.answered - m.correct) * 2 + m.days * 50; } // امتیاز لیگ
  window.MWStats = { load: load, save: save, record: record, streakNow: streakNow, weekDays: weekDays, weekBest: weekBest,
    acc: acc, dkey: dkey, addDays: addDays, compact: compact, weekPoints: weekPoints, GOAL: GOAL, CUP: CUP,
    fa: function (n) { return String(n).replace(/\d/g, function (d) { return "۰۱۲۳۴۵۶۷۸۹"[d]; }); } };
})();
