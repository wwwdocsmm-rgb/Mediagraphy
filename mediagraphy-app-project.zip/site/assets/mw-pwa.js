/* نصب از مرورگر (PWA) + کش آفلاین. داخل اپ Capacitor غیرفعال است. */
(function () {
  var C = window.Capacitor; if (C && C.isNativePlatform && C.isNativePlatform()) return;
  if (!("serviceWorker" in navigator)) return;
  if (location.protocol !== "https:" && location.hostname !== "localhost") return;
  var base = document.currentScript ? document.currentScript.src.replace(/assets\/[^\/]*$/, "") : "/";
  window.addEventListener("load", function () { navigator.serviceWorker.register(base + "sw.js").catch(function () {}); });
})();
