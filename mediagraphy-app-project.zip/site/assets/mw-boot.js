/* باید اولین اسکریپت <head> باشد: ترتیب شافل سؤال‌ها را با seed ثابت می‌کند تا «ادامه از آخرین سؤال» دقیق بازسازی شود. */
(function () {
  try {
    var KEY = "mw:seed:" + (window.MW_KEY || location.pathname.split("/").slice(-2).join("/"));
    var real = Math.random.bind(Math);
    window.__mwRandom = real;               // random واقعی برای کد خود MW
    var a = 1;
    function seedFrom(s) { a = s >>> 0 || 1; }
    window.__mwReseed = function () {       // شروع تلاش جدید
      var s = (real() * 4294967296) >>> 0 || 1;
      try { localStorage.setItem(KEY, String(s)); } catch (e) {}
      seedFrom(s);
    };
    var s0 = parseInt(localStorage.getItem(KEY), 10);
    if (!s0) { s0 = (real() * 4294967296) >>> 0 || 1; try { localStorage.setItem(KEY, String(s0)); } catch (e) {} }
    seedFrom(s0);
    Math.random = function () {             // mulberry32
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  } catch (e) {}
})();
